const esc = v => { const d = document.createElement('div'); d.textContent = v ?? ''; return d.innerHTML; };
const money = p => new Intl.NumberFormat('en-GB', { style: 'currency', currency: 'GBP' }).format((p || 0) / 100);
let register = false;
const form = document.querySelector('#loginForm'), alertBox = document.querySelector('#authAlert');

function setMode() {
  document.querySelectorAll('.register-only').forEach(x => x.style.display = register ? 'flex' : 'none');
  form.querySelector('button').textContent = register ? 'Create account' : 'Log in';
  document.querySelector('#toggleMode').textContent = register ? 'Log in instead' : 'Create account instead';
  form.password.autocomplete = register ? 'new-password' : 'current-password';
}

function paymentSummary(b) {
  const payment = b.payment_status || 'Deposit Due';
  const deposit = b.deposit_amount ? money(b.deposit_amount) : 'Deposit due';
  const balance = b.balance_amount ? money(b.balance_amount) : 'No balance due';
  return `
    <strong>${esc(payment)}</strong>
    <div class="date-sub">Total ${money(b.total_amount)}</div>
    <div class="date-sub">Deposit ${deposit}</div>
    <div class="date-sub">Balance ${balance}</div>`;
}

async function showPortal() {
  const r = await fetch('/api/customer/bookings'), bookings = await r.json();
  if (!r.ok) return;
  document.querySelector('#authPanel').hidden = true;
  document.querySelector('#portal').hidden = false;
  document.querySelector('#bookings').innerHTML = bookings.length ? `<table><thead><tr><th>Reference</th><th>Clean</th><th>Date</th><th>Status</th><th>Payments</th></tr></thead><tbody>${bookings.map(b => `<tr><td><strong>${esc(b.reference)}</strong><div class="date-sub">${esc(b.address)}, ${esc(b.postcode)}</div></td><td>${esc(b.clean_type)}<div class="date-sub">${b.bedrooms} bed · ${b.bathrooms} bath</div></td><td>${esc(b.preferred_date)}<div class="date-sub">${esc(b.preferred_time)}</div></td><td><span class="badge">${esc(b.status)}</span>${b.cleaner_name ? `<div class="assigned-to">${esc(b.cleaner_name)}</div>` : ''}</td><td>${paymentSummary(b)}</td></tr>`).join('')}</tbody></table>` : '<div class="empty">No Sparkles bookings yet. Book with the same email address and they will appear here.</div>';
}

form.onsubmit = async e => {
  e.preventDefault();
  alertBox.className = 'alert';
  const endpoint = register ? '/api/customer/register' : '/api/customer/login';
  try {
    const r = await fetch(endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(Object.fromEntries(new FormData(form))) }), data = await r.json();
    if (!r.ok) throw new Error(data.error || 'Could not continue.');
    showPortal();
  } catch (err) {
    alertBox.textContent = err.message;
    alertBox.className = 'alert error';
  }
};

document.querySelector('#toggleMode').onclick = e => { e.preventDefault(); register = !register; setMode(); };
document.querySelector('#logout').onclick = async () => { await fetch('/api/auth/logout', { method: 'POST' }); location.href = '/customer'; };
setMode();
showPortal();
